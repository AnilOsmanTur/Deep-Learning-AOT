Details about this assignment can be found [on the course webpage](http://kovan.ceng.metu.edu.tr/~sinan/DL/HW1/).
